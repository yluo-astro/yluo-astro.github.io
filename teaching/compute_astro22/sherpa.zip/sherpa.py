import numpy as np
import matplotlib.pyplot as plt
from astropy.modeling import models, fitting
import scipy.optimize
# Make plots display in notebooks


#######. astropy intro
##### load data
dat = np.loadtxt('spec.d')

wav = dat[:,0] 
wav_err= dat[:,1]
flux = dat[:,2]
flux_err = dat[:,3]
fit = dat[:,4]

########## make plot
fig, ax = plt.subplots()
 
ax.errorbar(wav, flux,
            xerr=wav_err,
            yerr=flux_err,
            fmt='.',color='k',ecolor='red')
 
ax.set_xlabel('x-axis')
ax.set_ylabel('y-axis')
ax.set_title('Line plot with error bars')
plt.show()


############ set model and fit
model = models.PowerLaw1D(amplitude=0.4, x_0=21, alpha=10)
fitter = fitting.SimplexLSQFitter()
best_fit = fitter(model, wav, flux, weights = 1.0/flux_err**2)


plt.plot(wav, best_fit(wav), color='b', linewidth=3, label='SimplexLSQFitter()')


########### good or bad of the fit
def calc_reduced_chi_square(fit, x, y, yerr, N, n_free):
    '''
    fit (array) values for the fit
    x,y,yerr (arrays) data
    N total number of points
    n_free number of parameters we are fitting
    '''
    return 1.0/(N-n_free)*sum(((fit - y)/yerr)**2)




reduced_chi_squared = calc_reduced_chi_square(best_fit(wav), wav, flux, flux_err, len(wav), 3)
print('Reduced Chi Squared with LinearLSQFitter: {}'.format(reduced_chi_squared))

################### reset model and fit
compound_model = models.Gaussian1D(-0.1, 21.6, 0.01) + models.PowerLaw1D(amplitude=0.4, x_0=21, alpha=10)

fitter = fitting.SimplexLSQFitter()
compound_fit = fitter(compound_model, wav, flux)
plt.plot(wav, compound_fit(wav), color='k', linewidth=3)

reduced_chi_squared = calc_reduced_chi_square(compound_fit(wav), wav, flux, flux_err, len(wav), 6)
print('Reduced Chi Squared: {}'.format(reduced_chi_squared))




###############################. sherpa intro
from astropy import units as u

from sherpa import data
from sherpa.astro import data as astrodata

from sherpa import plot
from sherpa.astro import plot as astroplot


from sherpa.astro import io
from sherpa.astro.plot import DataPHAPlot


######## load data
pha = io.read_pha('P0311590501R1S000SRSPEC1003.FIT',use_background=True)
#arf = io.read_arf('rgs.arf')
rmf = io.read_rmf('P0311590501R1S000RSPMAT1003.FIT')


########## first look at the data
plot = DataPHAPlot()
#plot.histo_prefs['linestyle'] = '-'
plot.prepare(pha)
plot.plot(xerrorbars=True, yerrorbars=True,linestyle='solid', alpha=0.5, marker=None)




############ data inspection
print(pha.get_background())
print(pha.get_arf())
print(pha.get_rmf())


###### change units
pha.get_analysis()
print(pha.units)

pha.set_analysis('wave')#, type='counts', factor=1)
plot.prepare(pha)
plot.plot()



pha.set_analysis('channel')#, type='counts', factor=1)
plot.prepare(pha)
plot.plot()

## ignore and notice
pha.units = 'wavelength'
plot.prepare(pha)
plot.plot(xlog=False, ylog=True)
pha.ignore(0,20)
pha.ignore(22,50)
plot.prepare(pha)
plot.plot(linestyle='solid', alpha=0.5, marker=None)



###### group
pha40 = io.read_pha('P0311590501R1S000SRSPEC1003.FIT',use_background=True)
pha100 = io.read_pha('P0311590501R1S000SRSPEC1003.FIT',use_background=True)
pha1000 = io.read_pha('P0311590501R1S000SRSPEC1003.FIT',use_background=True)

plt.close('all')
plt.figure(1)

pha40.group_counts(40)
pha40.set_analysis('wavelength')#, type='counts', factor=1)
pha40.ignore(0,20)
pha40.ignore(25,100)
plot.prepare(pha40)
plot.histo_prefs['color'] = 'k'
plot.plot(linestyle='solid', alpha=0.5, marker=None)


plt.figure(2)
pha100.group_counts(100)
pha100.set_analysis('wavelength')#, type='counts', factor=1)
pha100.ignore(0,20)
pha100.ignore(25,100)
plot.prepare(pha100)
plot.histo_prefs['color'] = 'r'
plot.plot(linestyle='solid', alpha=0.5, marker=None)

plt.figure(3)
pha1000.group_counts(1000)
pha1000.set_analysis('wavelength')#, type='counts', factor=1)
pha1000.ignore(0,20)
pha1000.ignore(25,100)
plot.prepare(pha1000)
plot.histo_prefs['color'] = 'r'
plot.plot(linestyle='solid', alpha=0.5, marker=None)




#####################. models
from sherpa.models.basic import PowLaw1D, Gauss1D
from sherpa.astro.models import Voigt1D, BBody,Atten

from sherpa.astro.instrument import Response1D


wabs = Atten('wabs')
pl = PowLaw1D('pl')
#line = Voigt1D('line')
line = Gauss1D('line')


mdl = wabs*pl#+line

wabs.hcol = 1e22
pl.gamma = 2.5
pl.ref = 20
pl.ampl = 50

#line.pos=21.6
#line.ampl = 100
#line.fwhm = 2


rsp = Response1D(pha)
model = rsp(mdl)
print(model)


#### model plot
mplot = ModelPlot()
mplot.prepare(pha, model)
mplot.plot()


pha.group_counts(40)
dplot = DataPHAPlot()
#plot.histo_prefs['linestyle'] = '-'
dplot.prepare(pha)
#dplot.overplot()
dplot.plot(overplot=True)




##########
from sherpa import models
from sherpa.plot import ModelPlot

from sherpa.astro.instrument import Response1D
from sherpa.models.basic import PowLaw1D, Gauss1D
from sherpa.astro.models import Voigt1D, BBody,Atten

wabs = Atten('wabs')
pl = PowLaw1D('pl')
#line = Voigt1D('line')
line = Gauss1D('line')


mdl = wabs*pl#+line

wabs.hcol = 1e22
pl.gamma = 2.5
pl.ref = 20
pl.ampl = 50

line.pos=21.6
line.ampl = 100
line.fwhm = 2

### response into model
rsp = Response1D(pha)
model = rsp(mdl)
print(model)


### plot model
dplot = DataPHAPlot()
#plot.histo_prefs['linestyle'] = '-'
dplot.prepare(pha)
#dplot.overplot()
dplot.plot(linestyle='solid', alpha=0.9, marker=None, color='b')

mplot = ModelPlot()
mplot.prepare(pha, model)
mplot.plot(overplot=True,color='r')


#################### fit
from sherpa.stats import LeastSq
from sherpa.optmethods import LevMar
from sherpa.fit import Fit

stat = LeastSq()
opt = LevMar()
print(opt)

f = Fit(pha, model, stat=LeastSq(), method=LevMar())
res = f.fit()
if res.succeeded: print("Fit succeeded")
print(res.format())


from sherpa.plot import FitPlot

figure()
fplot = FitPlot()
mplot.prepare(f.data, f.model)
fplot.prepare(dplot, mplot)
fplot.plot(overplot=False,linestyle='solid', marker=None)


############
#fit_info = f.calc_stat_info()
#print(fit_info)


######## change optimastic method
from sherpa.optmethods import NelderMead

f.method = NelderMead()
res = f.fit()
print("Change in statistic: {}".format(res.dstatval))



from sherpa.stats import CStat

f.method = NelderMead()
f.stat = CStat()
res = f.fit()
print("Change in statistic: {}".format(res.rstat))


########## add model
#line = Voigt1D('line')
line = Gauss1D('line')


mdl = wabs*pl+line

wabs.hcol = 1e22
pl.gamma = 2.5
pl.ref = 20
pl.ampl = 50

line.pos=21.6
line.ampl = -4
line.fwhm = 1e-3

### response into model
rsp = Response1D(pha)
model = rsp(mdl)
print(model)

f = Fit(pha, model, stat=LeastSq(), method=LevMar())
res = f.fit()
if res.succeeded: print("Fit succeeded")
print(res.format())



####### error estimate
from sherpa.estmethods import Confidence
f.estmethod = Confidence()
print(f.estmethod)
errors = f.est_errors()



