"""
Neural Network Diagram
----------------------
"""

import numpy as np
import matplotlib.pyplot as plt
import pandas as pd


######### Data Preprocessing
dataset = pd.read_csv('Churn_Modelling.csv')
dataset.head()

X = pd.DataFrame(dataset.iloc[:, 3:13].values)
y = dataset.iloc[:, 13].values


######### Data preprocessing

from sklearn.preprocessing import LabelEncoder, OneHotEncoder

labelencoder_X_1 = LabelEncoder()
X.loc[:, 1] = labelencoder_X_1.fit_transform(X.iloc[:, 1])

labelencoder_X_2 = LabelEncoder()
X.loc[:, 2] = labelencoder_X_2.fit_transform(X.iloc[:, 2])

##Now creating Dummy variables
#onehotencoder = OneHotEncoder(categorical_features = [1])
#X = onehotencoder.fit_transform(X).toarray()
#X = X[:, 1:]



################## Splitting the dataset into the Training set and Test set

from sklearn.model_selection import train_test_split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size = 0.2, random_state = 0)



##################### Feature Scaling

from sklearn.preprocessing import StandardScaler
sc = StandardScaler()
X_train = sc.fit_transform(X_train)
X_test = sc.transform(X_test)




################## Now let’s make the ANN!
import keras
from keras.models import Sequential
from keras.layers import Dense
import tensorflow as tf
from tensorflow.keras import models, layers, utils, backend as K
import matplotlib.pyplot as plt
#import shap

##Initializing the ANN…
## So there are actually 2 ways of initializing a deep learning model
## — — — 1)Defining each layer one by one
## — — — 2)Defining a Graph



n_features = 10
annmodel = models.Sequential(name="DeepNN", layers=[
    ### hidden layer 1
    layers.Dense(name="h1", input_dim=n_features,
                 units=int(round((n_features+1)/2)), 
                 activation='relu'),
    layers.Dropout(name="drop1", rate=0.2),
    
    ### hidden layer 2
    layers.Dense(name="h2", units=int(round((n_features+1)/4)), 
                 activation='relu'),
    layers.Dropout(name="drop2", rate=0.2),
    
    ### layer output
    layers.Dense(name="output", units=1, activation='sigmoid')
])
annmodel.summary()

#### if change activation func
# define the function
#def binary_step_activation(x):
    ##return 1 if x>0 else 0 
#    return K.switch(x>0, tf.math.divide(x,x), tf.math.multiply(x,0))

#model = models.Sequential(name="Perceptron", layers=[
#      layers.Dense(             
#          name="dense",
#          input_dim=3,        
#          units=1,            
#          activation=binary_step_activation
#      )
#])

# another method to dedign model
### layer input
n_features = 10
inputs = layers.Input(name="input", shape=(n_features,))
### hidden layer 1
h1 = layers.Dense(name="h1", units=int(round((n_features+1)/2)), activation='relu')(inputs)
#h1 = layers.Dropout(name="drop1", rate=0.2)(h1)### hidden layer 2
h2 = layers.Dense(name="h2", units=int(round((n_features+1)/4)), activation='relu')(h1)
#h2 = layers.Dropout(name="drop2", rate=0.2)(h2)### layer output
outputs = layers.Dense(name="output", units=1, activation='sigmoid')(h2)
annmodel = models.Model(inputs=inputs, outputs=outputs, name="DeepNN")



## — →Here avg= (11+1)/2==>6 So set Output Dim=6
## — →Init will initialize the Hidden Layer weights uniformly
## — →Activation Function is Rectifier Activation Function(Relu)

#number of nodes in the Input Layer. 
nnmodel.add(Dense(output_dim = 6, init = 'uniform', activation = 'relu', input_dim = 11))
#Adding the second hidden layer…
nnmodel.add(Dense(output_dim = 6, init = 'uniform', activation = 'relu'))
#Adding the output layer…
nnmodel.add(Dense(output_dim = 1, init = 'uniform', activation = 'sigmoid'))


######### visualize the model
from visualize import visualize_nn
visualize_nn(annmodel, description=True, figsize=(10,8))



######
### Compiling the ANN…
annmodel.compile(optimizer = 'adam', loss = 'binary_crossentropy', metrics = ['accuracy'])

#annmodel.compile(loss='categorical_crossentropy', optimizer=RMSprop(),
#                metrics=['accuracy'])

# define metrics
def R2(y, y_hat):
    ss_res =  K.sum(K.square(y - y_hat)) 
    ss_tot = K.sum(K.square(y - K.mean(y))) 
    return ( 1 - ss_res/(ss_tot + K.epsilon()) )
# compile the neural network
annmodel.compile(optimizer='adam', loss='mean_absolute_error', 
              metrics=[R2])


# or define new metrics
def Recall(y_true, y_pred):
    true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
    possible_positives = K.sum(K.round(K.clip(y_true, 0, 1)))
    recall = true_positives / (possible_positives + K.epsilon())
    return recall

def Precision(y_true, y_pred):
    true_positives = K.sum(K.round(K.clip(y_true * y_pred, 0, 1)))
    predicted_positives = K.sum(K.round(K.clip(y_pred, 0, 1)))
    precision = true_positives / (predicted_positives + K.epsilon())
    return precision

def F1(y_true, y_pred):
    precision = Precision(y_true, y_pred)
    recall = Recall(y_true, y_pred)
    return 2*((precision*recall)/(precision+recall+K.epsilon()))
# compile the neural network
nnmodel.compile(optimizer='adam', loss='binary_crossentropy', 
              metrics=['accuracy',F1])
              


######### train the model              
training = annmodel.fit(x=X, y=y, batch_size=32, epochs=100, shuffle=True, verbose=0, validation_split=0.3)



######## Fitting the ANN to the Training set
training = annmodel.fit(X_train,y_train,batch_size=32,epochs = 100)


history = annmodel.fit(X_train,y_train,
                      batch_size=32,
                      epochs=100,
                      verbose=2,
                      validation_data=(X_test, y_test))





############### Making the predictions and evaluating the model

score = annmodel.evaluate(X_test, y_test, verbose=0)
print('Test loss:', score[0])
print('Test accuracy:', score[1])
score = annmodel.evaluate(X_train,y_train, verbose=0)
print('Test loss:', score[0])
print('Test accuracy:', score[1])


##########
y_pred = annmodel.predict(X_test)
y_pred = (y_pred > 0.5)
#print(y_pred)
###################### Making the Confusion Matrix

from sklearn.metrics import confusion_matrix, accuracy_score
cm = confusion_matrix(y_test, y_pred)
print(cm)
accuracy_score(y_test,y_pred)









# plot
metrics = [k for k in training.history.keys() if ("loss" not in k) and ("val" not in k)]    
fig, ax = plt.subplots(nrows=1, ncols=2, sharey=True, figsize=(15,3))
       
## training    
ax[0].set(title="Training")    
ax11 = ax[0].twinx()    
ax[0].plot(training.history['loss'], color='black')    
ax[0].set_xlabel('Epochs')    
ax[0].set_ylabel('Loss', color='black')    
for metric in metrics:        
    ax11.plot(training.history[metric], label=metric)    
    ax11.set_ylabel("Score", color='steelblue')    

ax11.legend()
        
## validation    
ax[1].set(title="Validation")    
ax22 = ax[1].twinx()    
ax[1].plot(training.history['accuracy'], color='black')    
ax[1].set_xlabel('Epochs')    
ax[1].set_ylabel('Loss', color='black')    
for metric in metrics:          
    ax22.plot(training.history['val_'+metric], label=metric)    
    ax22.set_ylabel("Score", color="steelblue")    

plt.show()

















